﻿namespace SmsBomber.SmsService
{
    internal class DomainList
    {
        public const string Alpari = "https://alpari.com";
        public const string FindClone = "https://findclone.ru/";
        public const string Tinder = "https://api.gotinder.com";
        public const string Twitch = "https://passport.twitch.tv";
        public const string Invitro = "https://lk.invitro.ru";
        public const string Youla = "https://youla.ru";
        public const string GuruTaxi = "https://guru.taxi";
    }
}

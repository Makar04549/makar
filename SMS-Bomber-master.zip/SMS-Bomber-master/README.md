![SMS-Bomber](Logo/SMS-Bomber.png)
[![C# .NET Framework 4.6.2](https://img.shields.io/badge/C%23-.NET%20Framework%204.6.2-blueviolet)](https://dotnet.microsoft.com/download/dotnet-framework)
[![Version 1.0](https://img.shields.io/badge/Version-1.0-blue.svg?cacheSeconds=2592000)](https://github.com/DeWizzard/SMS-Bomber/releases)
##                Программа для массового спама SMS на номер телефона:bomb:
![Programm Image](https://raw.githubusercontent.com/DeWizzard/SMS-Bomber/master/Images/Programm.png?token=AL6H64E7SQ3VTVGQJCHSJCS6BMCXY)
## Возможности программы:
- Отправка SMS на номер телефона с разных сервисов в многопотоке
- Получение информации о номере телефона
## Описание настроек:
1. Кол-во циклов
   - Количество циклов которые выполнит программа, в одном цикле 7 сайтов
2. Задержка(ms)
   - Задержка после каждого выполненного цикла, указывается в миллисекундах
3. Кол-во потоков
   - Количество потоков которые будут запущены, не рекомендуется больше 100
4. Номер
   - Мобильный номер телефона для спама, указывать без символов
5. Тип прокси
   - HTTP
   - SOCKS4A
   - SOCKS4
   - SOCKS5
6. Сайты
   - Сайты с которых будут отправляться SMS
## Зависимости:
* [.NET Framework 4.6.2](https://dotnet.microsoft.com/download/dotnet-framework)
* [Leaf.xNet 5.1.88](https://www.nuget.org/packages/Leaf.xNet/)
* [MetroModernUI 1.4.0.0](https://www.nuget.org/packages/MetroModernUI/)
